# Copyright (c) OpenMMLab. All rights reserved.
from abc import ABCMeta, abstractmethod
from typing import List, Union

import math
import torch
import torch.nn as nn
from mmdet.utils import ConfigType, OptMultiConfig
from mmengine.model import BaseModule
from torch.nn.modules.batchnorm import _BatchNorm

from mmyolo.registry import MODELS

@MODELS.register_module()
class DCNv2(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1,
                 padding=1, dilation=1, groups=1, deformable_groups=1):
        super(DCNv2, self).__init__()

        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = (kernel_size, kernel_size)
        # self.kernel_size = kernel_size
        self.stride = (stride, stride)
        self.padding = (padding, padding)
        self.dilation = (dilation, dilation)
        self.groups = groups
        self.deformable_groups = deformable_groups

        self.weight = nn.Parameter(
            torch.empty(out_channels, in_channels, *self.kernel_size)
        )
        self.bias = nn.Parameter(torch.empty(out_channels))

        out_channels_offset_mask = (self.deformable_groups * 3 *
                                    self.kernel_size[0] * self.kernel_size[1])
        self.conv_offset_mask = nn.Conv2d(
            self.in_channels,
            out_channels_offset_mask,
            kernel_size=self.kernel_size,
            stride=self.stride,
            padding=self.padding,
            bias=True,
        )

        self.reset_parameters()

    def forward(self, x):
        offset_mask = self.conv_offset_mask(x)
        oh, ow, mask = torch.chunk(offset_mask, 3, dim=1)
        offset = torch.cat((oh, ow), dim=1)
        mask = torch.sigmoid(mask)

        x = torch.ops.torchvision.deform_conv2d(
            x,
            self.weight,
            offset,
            mask,
            self.bias,
            self.stride[0], self.stride[1],
            self.padding[0], self.padding[1],
            self.dilation[0], self.dilation[1],
            self.groups,
            self.deformable_groups,
            True
        )

        return x

    def reset_parameters(self):
        n = self.in_channels
        for k in self.kernel_size:
            n *= k
        std = 1. / math.sqrt(n)
        self.weight.data.uniform_(-std, std)
        self.bias.data.zero_()
        self.conv_offset_mask.weight.data.zero_()
        self.conv_offset_mask.bias.data.zero_()

@MODELS.register_module()
class FRSYOLONeck(nn.Module):

    def __init__(self,
                 in_channels: List[int],
                 out_channels: Union[int, List[int]],
                 ):
        # super().__init__(init_cfg)
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels

        #dcnv2_blocks
        self.dcn_blocks = nn.ModuleList()
        for idx in range(len(in_channels)):
            self.dcn_layers = nn.Sequential(
                DCNv2(in_channels=in_channels[idx], out_channels=out_channels[idx], kernel_size=3),
                DCNv2(in_channels=in_channels[idx], out_channels=out_channels[idx], kernel_size=3),
                DCNv2(in_channels=in_channels[idx], out_channels=out_channels[idx], kernel_size=3)
            )
            self.dcn_blocks.append(self.dcn_layers)

        self.sup_block = nn.ModuleList()
        for idx in range(len(in_channels)):
            self.conv1 = nn.Sequential(
                nn.Conv2d(in_channels=in_channels[idx], out_channels=1, kernel_size=1, stride=1, padding="same"),
            )
            self.sup_block.append(self.conv1)


    def forward(self, inputs: List[torch.Tensor]) -> tuple:
        """Forward function."""
        assert len(inputs) == len(self.in_channels)
        x_dcn_outs = []
        x_sup_outs = []
        for idx in range(len(self.in_channels)):
            x_dcn_outs.append(self.dcn_blocks[idx](inputs[idx]))
            x_sup_outs.append(self.sup_block[idx](inputs[idx]))
        # out_layers
        results = x_dcn_outs+x_sup_outs

        if torch.isnan(results[0].mean()):
            aaa=0

        return tuple(results)