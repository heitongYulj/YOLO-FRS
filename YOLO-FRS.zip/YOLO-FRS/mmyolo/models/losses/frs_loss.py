import matplotlib
import matplotlib.pyplot as plt
matplotlib.use('TKAgg')

import torch
import torch.nn as nn
import numpy as np

from mmyolo.registry import MODELS
# from utils.metrics import bbox_iou
# from utils.torch_utils import is_parallel
# import torch.nn.functional as F

class QFocalLoss(nn.Module):
    # Wraps Quality focal loss around existing loss_fcn(), i.e. criteria = FocalLoss(nn.BCEWithLogitsLoss(), gamma=1.5)
    def __init__(self, loss_fcn=nn.BCEWithLogitsLoss(), gamma=1.5, alpha=0.25):
        super().__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'  # required to apply FL to each element

    def forward(self, pred, true):

        pred = torch.clamp(pred, min=1e-7, max=1 - 1e-7)
        true = torch.clamp(true, min=1e-7, max=1 - 1e-7)

        loss = self.loss_fcn(pred, true)

        pred_prob = torch.sigmoid(pred)  # prob from logits
        alpha_factor = true * self.alpha + (1 - true) * (1 - self.alpha)
        modulating_factor = torch.abs(true - pred_prob) ** self.gamma
        loss *= alpha_factor * modulating_factor

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss

@MODELS.register_module()
class QFocalLoss_box(nn.Module):
    def __init__(self, loss_fcn=nn.BCEWithLogitsLoss(), gamma=1.5, alpha=0.25, ori_image_size=[640, 640]):
        super().__init__()
        self.loss_fcn = loss_fcn  # must be nn.BCEWithLogitsLoss()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = loss_fcn.reduction
        self.loss_fcn.reduction = 'none'
        # self.loss_fcn.reduction = 'mean'
        self.ori_image_size = ori_image_size

    def forward(self, pred, true):
        seg_true_all = self.build_targets(self.ori_image_size, pred, true, img_batch=pred[0].shape[0])
        # seg_true = seg_true_all[0]

        device = pred[0].device
        lsub = torch.zeros(1, device=device)[0]
        for i, sub_pi in enumerate(pred):
            sub_pi = torch.clamp(sub_pi, min=1e-7, max=1 - 1e-7)
            seg_true = torch.clamp(seg_true_all[i], min=1e-7, max=1 - 1e-7)
            lsb_i = self.compute_loss(sub_pi, seg_true)
            # lsb_i = lsb_i_all.mean()
            lsub += lsb_i


        return lsub

    def compute_loss(self, sub_pi, seg_true):
        loss = self.loss_fcn(sub_pi, seg_true)

        pred_prob = torch.sigmoid(sub_pi)  # prob from logits
        alpha_factor = seg_true * self.alpha + (1 - seg_true) * (1 - self.alpha)
        modulating_factor = torch.abs(seg_true - pred_prob) ** self.gamma
        loss *= alpha_factor * modulating_factor

        loss = torch.where(torch.isnan(loss), torch.full_like(loss,1e-7), loss)

        if torch.isnan(loss.mean()):
            aaa=0

        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'sum':
            return loss.sum()
        else:  # 'none'
            return loss


    def build_targets(self, ori_image_size, sub, targets, img_batch):

        # Build targets for compute_loss(), input targets(image,class,x,y,w,h)
        # na:number of anchors   nt:number of targets
        device = sub[0].device

        targets[:,2:] = targets[:,2:] /ori_image_size[0]

        na, nt = len(sub), targets.shape[0]  # number of anchors, targets

        tsub = []

        # gain = torch.ones(7, device=targets.device)  # normalized to gridspace gain
        ai = torch.arange(na, device=targets.device).float().view(na, 1).repeat(1, nt)  # same as .repeat_interleave(nt)
        targets = torch.cat((targets.repeat(na, 1, 1), ai[:, :, None]), 2)  # append anchor indices


        for i in range(len(sub)):

            batch_size = img_batch
            tsub_ii = torch.zeros((batch_size, 1, len(sub[i][0][:][0]), len(sub[i][0][0][:]))).to(device)
            tsub_ii_G = torch.zeros((batch_size, 1, len(sub[i][0][:][0]), len(sub[i][0][0][:]))).to(device)
            for batch_i in range(batch_size):
                box_xy = []
                box_wh = []
                obj_num = 0
                for target_i in range(len(targets[0])):

                    if batch_i==targets[i][target_i][0]:

                        x1 = torch.round(targets[i][target_i][2] * sub[i].shape[2])
                        y1 = torch.round(targets[i][target_i][3] * sub[i].shape[2])
                        x2 = torch.round(targets[i][target_i][4] * sub[i].shape[2])
                        y2 = torch.round(targets[i][target_i][5] * sub[i].shape[2])
                        box_xy = [torch.round((x1 + x2)/2), torch.round((y1 + y2)/2)]
                        box_wh = [(x2 - x1), (y2 - y1)]
                        if box_wh[0]==0:
                            box_wh[0] = torch.cuda.FloatTensor(1)
                        if box_wh[1]==0:
                            box_wh[1] = torch.cuda.FloatTensor(1)

                        tsub_ii[batch_i, 0, x1.type(torch.int).item():x2.type(torch.int).item(),y1.type(torch.int).item():y2.type(torch.int).item()] = 1
                        tsub_ii.to(device)

                        avg_wh = (box_wh[0] + box_wh[1]) / 2
                        f_w = len(sub[i][0][:][0])
                        f_h = len(sub[i][0][0][:])
                        x,y = np.meshgrid(np.linspace(0,f_w-1,f_w), np.linspace(0,f_h-1,f_h))
                        x_t = torch.from_numpy(x).to(device)
                        y_t = torch.from_numpy(y).to(device)
                        z = (x_t - box_xy[0]) ** 2 + (y_t - box_xy[1]) ** 2
                        gama = 2
                        one_obj_seg = torch.transpose(torch.exp(-(z / (2 * avg_wh ** 2)) ** gama), 0, 1)
                        tsub_ii_G[batch_i, 0, :, :] = torch.maximum(tsub_ii_G[batch_i, 0, :, :], one_obj_seg)

                        obj_num += 1

            tsub.append(tsub_ii_G)


        return tsub