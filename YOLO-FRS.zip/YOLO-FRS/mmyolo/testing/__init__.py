# Copyright (c) OpenMMLab. All rights reserved.
from ._utils import get_detector_cfg

__all__ = ['get_detector_cfg']
