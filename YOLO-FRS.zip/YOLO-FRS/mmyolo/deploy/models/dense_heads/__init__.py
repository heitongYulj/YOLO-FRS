# Copyright (c) OpenMMLab. All rights reserved.
from . import yolov5_head  # noqa: F401,F403

__all__ = ['yolov5_head']
